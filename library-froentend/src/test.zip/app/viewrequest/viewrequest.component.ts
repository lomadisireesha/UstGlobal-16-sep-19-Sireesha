import { Component, OnInit } from '@angular/core';
import { UrlsService } from '../urls.service';

@Component({
  selector: 'app-viewrequest',
  templateUrl: './viewrequest.component.html',
  styleUrls: ['./viewrequest.component.css']
})
export class ViewrequestComponent implements OnInit {

  books: any;
  constructor(myService: UrlsService) {
    console.log('Hi from Products Component');
    myService.viewRequest()
    .subscribe(responseData => {
      console.log('this is my data');
      console.log(responseData);
      this.books = responseData;
    }, error => {
      console.log(error);
    });
    console.log('subscription ended');
  }
  ngOnInit() {
  }

}
