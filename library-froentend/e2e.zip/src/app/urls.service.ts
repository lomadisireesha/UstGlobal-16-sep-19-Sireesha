import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UrlsService {

  isALoggedIn = false;
  isLLoggedIn = false;
  isSLoggedIn = false;
  home = true;


  constructor(private http: HttpClient) { }
  isAdminLoggedIn() {
    if (this.isALoggedIn) {
      return true;
    }
    return false;
  }

  isLibrarianLoggedIn() {
    if (this.isLLoggedIn) {
      return true;
    }
    return false;
  }

  isStudentLoggedIn() {
    if (this.isSLoggedIn) {
      return true;
    }
    return false;
  }
  registerUser(user: any): Observable<any> {
    return this.http.post(`http://localhost:8080/librarymanagementsystem/registeruser`, user);
  }
  loginUser(user: any): Observable<any> {
    return this.http.post(
      `http://localhost:8080/librarymanagementsystem/login/${user.id}/${user.password}`, user);
  }
  addBook(addBook: any): Observable<any> {

    return this.http.post(`http://localhost:8080/librarymanagementsystem/addbook`, addBook);
  }
  displayBook(): Observable<any> {

    return this.http.get(`http://localhost:8080/librarymanagementsystem/showbooks`);


  }
  request(book: any): Observable<any> {

    return this.http.post(`http://localhost:8080/librarymanagementsystem/requestingbook`, book);

  }
  viewRequest(): Observable<any> {

    return this.http.get(`http://localhost:8080/librarymanagementsystem`);
  }

  issuedBook(issuedbook: any): Observable<any> {

    return this.http.post(`http://localhost:8080/librarymanagementsystem`, issuedbook);
  }
}
