import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuard} from '../auth.guard';
import { UrlsService } from '../urls.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent  {

  constructor(private router: Router , private service : UrlsService ) { }

  get isALoggedIn() {
    return this.service.isAdminLoggedIn();
  }

  get isLLoggedIn() {
    return this.service.isLibrarianLoggedIn();
  }

  get isSLoggedIn() {
    return this.service.isStudentLoggedIn();
  }

  logout() {
    this.service.isALoggedIn = false;
    this.service.isLLoggedIn = false;
    this.service.isSLoggedIn = false;
    this.router.navigate(['/login']);
  }

}

