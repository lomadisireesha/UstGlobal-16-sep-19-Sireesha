import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-issuedbook',
  templateUrl: './issuedbook.component.html',
  styleUrls: ['./issuedbook.component.css']
})
export class IssuedbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
