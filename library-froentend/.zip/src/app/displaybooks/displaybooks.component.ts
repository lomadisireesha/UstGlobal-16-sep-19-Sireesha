import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displaybooks',
  templateUrl: './displaybooks.component.html',
  styleUrls: ['./displaybooks.component.css']
})
export class DisplaybooksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
